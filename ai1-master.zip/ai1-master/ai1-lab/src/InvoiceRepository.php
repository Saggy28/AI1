<?php
require_once __DIR__ . '/../autoload.php';

class InvoiceRepository
{
    public function getInvoice($id)
    {
        return ['abc'];
    }
}
