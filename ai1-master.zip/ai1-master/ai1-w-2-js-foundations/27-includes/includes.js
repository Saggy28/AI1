alert("From external JS file");
