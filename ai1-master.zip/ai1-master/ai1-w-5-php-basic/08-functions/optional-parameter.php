<?php

function sayHello($name = "Traveller")
{
    echo "Hello $name!<br/>";
}

sayHello('Jon');
sayHello();
