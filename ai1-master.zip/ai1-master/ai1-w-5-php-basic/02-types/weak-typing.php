<?php

$a = 1;
var_dump($a);
// int 1

$a = "abc";
var_dump($a);
// string 'abc' (length=3)

$a = true;
var_dump($a);
// boolean true
