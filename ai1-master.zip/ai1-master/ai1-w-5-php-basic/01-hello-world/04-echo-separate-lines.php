<?php

$title = "Welcome to PHP!";
$date = date('Y-m-d H:i:s');

echo "<!DOCTYPE html>\n";
echo "<html lang='en'>\n";
echo "<head>\n";
echo "    <meta charset='UTF-8'>\n";
echo "    <title>$title</title>\n";
echo "</head>\n";
echo "<body>\n";
echo "$title<br/>\n";
echo "Today is: <strong>$date</strong>\n";
echo "</body>\n";
echo "</html>\n";
