<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to PHP!</title>
</head>
<body>
Welcome to PHP!
</body>
</html>
