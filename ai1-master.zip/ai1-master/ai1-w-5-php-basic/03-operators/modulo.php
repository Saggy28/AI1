<?php

var_dump(0 % 3);
// int 0

var_dump(1 % 3);
// int 1

var_dump(2 % 3);
// int 2

var_dump(3 % 3);
// int 3

var_dump(4 % 3);
// int 4
