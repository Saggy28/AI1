<?php

$a = 5;
$b = "7days";

var_dump($a + $b);
//--> ???

var_dump($a . $b);
//--> ???
