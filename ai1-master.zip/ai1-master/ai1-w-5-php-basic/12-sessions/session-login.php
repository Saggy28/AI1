<?php

session_start();
$_SESSION['uid'] = 12;
