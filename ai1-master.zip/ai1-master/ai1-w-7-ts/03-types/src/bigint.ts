function bigint() {
    // let a = 1234n;
    // TS2737: BigInt literals are not available
    //         when targeting lower than ES2020.

    // let b : bigint = 1234n;
    // TS2737: BigInt literals are not available
    //         when targeting lower than ES2020.
}
bigint();
