function inferTypes() {
    let a = 10;
    a = 20;
    // a = "a";

    let b = true;
    b = false;
    // b = null;
}
inferTypes();
