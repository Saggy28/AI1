console.log(5 + [5]);
//--> 55

(5).toString() + [5].toString()
//--> 55
