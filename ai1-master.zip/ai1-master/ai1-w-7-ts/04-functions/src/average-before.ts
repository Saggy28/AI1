function averageBefore() {
    // function average

    // console.log(average());
    // //--> 0
    // console.log(average(5));
    // //--> 5
    // console.log(average(5, 10, 15));
    // //--> 10
    //
    // let values = [5, 10, 15];
    // console.log(average(...values));
    // //--> 10
}
averageBefore();
