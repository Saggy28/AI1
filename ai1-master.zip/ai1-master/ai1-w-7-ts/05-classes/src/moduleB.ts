// moduleB.ts
import { hello } from './moduleA';

hello();
//--> Hello!
