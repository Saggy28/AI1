function myFunction() {
    console.log("Hello A");
}

// function myFunction() {
//     console.log("Hello B");
// }
// TS2393: Duplicate function implementation.
