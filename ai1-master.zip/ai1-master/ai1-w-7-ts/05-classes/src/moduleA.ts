// moduleA.ts
export function hello() {
    console.log("Hello!");
}
