<?php
$config = [];
$config['dsn'] = "sqlite:" . __DIR__."/../data.db";
$config['username'] = 'homestead';
$config['password'] = 'secret';
