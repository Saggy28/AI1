<?php

final class Employee {}
//class JuniorEmployee extends Employee{} // fatal error

class Student {
    final public function getName() {}
}
//class Graduate extends Student {
//    public final function getName() {} // fatal error
//}
