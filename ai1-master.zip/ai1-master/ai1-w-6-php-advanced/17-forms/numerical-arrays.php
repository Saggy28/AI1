<?php

var_dump($_REQUEST);
?>
<form method="post">
    <input type="checkbox" name="option[]" value="opt1" />
    <input type="checkbox" name="option[]" value="opt2" />
    <input type="submit" />
</form>
