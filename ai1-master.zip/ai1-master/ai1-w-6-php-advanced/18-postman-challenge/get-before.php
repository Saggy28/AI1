<?php

// get data to $items array
$items = [];

// convert the $items array to JSON-string
$itemsJson = '';

// show browser the response is an application/json content type and echo the JSON

