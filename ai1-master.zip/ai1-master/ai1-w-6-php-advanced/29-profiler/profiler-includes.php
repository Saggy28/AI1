<?php

function f1()
{
   echo "1";
}

function f2()
{
    sleep(1);
    echo "2";
}

function f3()
{
    echo "3";
}
