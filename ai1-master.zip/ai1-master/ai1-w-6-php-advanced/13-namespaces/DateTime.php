<?php

namespace MyNamespace;

class DateTime
{
    public function format($format = null)
    {
        return "Ha ha ha!";
    }
}
