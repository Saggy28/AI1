<?php
require_once __DIR__ . '/../../common-autoload.php';

// steel sword
$sword = new SteelSword();
$sword->display();

// steel sword with spell
// $sword = ...
$sword->display();

// steel sword with rune
// $sword = ...
$sword->display();
// add spell
//$sword = ...
$sword->display();

// add name "Moonlight Butcher"
// $sword = ...
$sword->display();
