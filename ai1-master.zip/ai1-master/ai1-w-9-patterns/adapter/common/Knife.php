<?php
class Knife implements CuttableInterface
{
    public function cut()
    {
        echo "A surprise cut with the assassin's hidden knife.\n";
    }
}
