<?php
class Crossbow implements ShootableInterface
{
    public function shoot()
    {
        echo "A fast shot with a crossbow.\n";
    }
}
