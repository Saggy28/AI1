<?php
interface CuttableInterface
{
    public function cut();
}
