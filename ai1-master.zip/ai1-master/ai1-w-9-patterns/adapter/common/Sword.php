<?php
class Sword implements CuttableInterface
{
    public function cut()
    {
        echo "A strong cut with a sword.\n";
    }
}
