<?php
interface ShootableInterface
{
    public function shoot();
}
