<?php
interface ThrowableInterface
{
    public function doThrow();
}
