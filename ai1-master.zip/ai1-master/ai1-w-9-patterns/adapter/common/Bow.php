<?php
class Bow implements ShootableInterface
{
    public function shoot()
    {
        echo "A shot with a bow.\n";
    }
}
