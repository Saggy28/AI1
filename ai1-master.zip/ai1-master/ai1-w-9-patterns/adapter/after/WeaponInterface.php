<?php
interface WeaponInterface
{
    public function attack();
}
