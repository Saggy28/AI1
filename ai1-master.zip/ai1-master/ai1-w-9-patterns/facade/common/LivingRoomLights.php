<?php
class LivingRoomLights
{
    public function on()
    {
        echo "Living room lights on!\n";
    }

    public function off()
    {
        echo "Living room lights off!\n";
    }
}
