<?php
class ChristmasLights
{
    public function on()
    {
        echo "Christmas lights on!\n";
    }

    public function off()
    {
        echo "Christmas lights off!\n";
    }
}
