<?php
class GingerAromatizer
{
    public function on()
    {
        echo "It starts to smell ginger aroma!\n";
    }

    public function off()
    {
        echo "Ginger aroma gone :(\n";
    }
}
