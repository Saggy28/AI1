<?php
class Radio
{
    public function playLastChristmas()
    {
        echo "Laaast Christmas, I gave you my heaaart, but the very next dayyy, you gave it awaaaay....\n";
    }

    public function playDrivingHomeForChristmas()
    {
        echo "Tam dim dim dim dam I'm driving home for Christmas....\n";
    }

    public function stopMusic()
    {
        echo "Radio off.\n";
    }
}
