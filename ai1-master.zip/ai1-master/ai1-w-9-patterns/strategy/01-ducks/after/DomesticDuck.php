<?php

class DomesticDuck extends Duck
{
    public function getName()
    {
        return "Domestic Duck";
    }
}
