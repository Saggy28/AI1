<?php

class MarbledDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a Marbled duck!\n";
    }
}
