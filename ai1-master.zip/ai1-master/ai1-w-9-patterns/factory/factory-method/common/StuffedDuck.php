<?php

class StuffedDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a stuffed duck!\n";
    }
}
