<?php

class DomesticDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a Domestic duck!\n";
    }
}
