<?php

class MallardDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a Mallard duck!\n";
    }
}
