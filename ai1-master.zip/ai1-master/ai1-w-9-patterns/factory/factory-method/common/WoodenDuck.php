<?php

class WoodenDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a wooden duck!\n";
    }
}
