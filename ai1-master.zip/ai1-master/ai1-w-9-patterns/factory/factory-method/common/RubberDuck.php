<?php

class RubberDuck extends AbstractDuck
{
    public function display()
    {
        echo "I am a rubber duck!\n";
    }
}
