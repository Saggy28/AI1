<?php

abstract class AbstractDuck
{
    abstract public function display();
}
